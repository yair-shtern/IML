import sklearn

from IMLearn import BaseEstimator
from challenge.agoda_cancellation_estimator import AgodaCancellationEstimator
from sklearn.model_selection import train_test_split
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder


def load_data(filename: str, train=True):
    """
    Load Agoda booking cancellation dataset
    Parameters
    ----------
    filename: str
        Path to house prices dataset

    Returns
    -------
    Design matrix and response vector in either of the following formats:
    1) Single dataframe with last column representing the response
    2) Tuple of pandas.DataFrame and Series
    3) Tuple of ndarray of shape (n_samples, n_features) and ndarray of shape (n_samples,)
    """
    full_data = pd.read_csv(filename,
                            ).replace("Pay Now", 1). \
        replace("Pay Later", 0).replace("Pay at Check-in", -1) \
        .replace('TRUE', 1).replace('FALSE', 0).drop_duplicates()

    if train:
        full_data = full_data.dropna()
    else:
        full_data = full_data.fillna(0)
    # booking_datetime = full_data["booking_datetime"]

    full_data["days_before_checking"] = (pd.to_datetime(full_data["checkin_date"], dayfirst=True) -
                                         pd.to_datetime(full_data["booking_datetime"], dayfirst=True)).dt.days

    if train == True:
        f = np.zeros(full_data.shape[0])
        booking = np.array(full_data["booking_datetime"])
        canceling = np.array(full_data["cancellation_datetime"])
        for i in range(full_data.shape[0]):
            date = pd.to_datetime(booking[i], errors="coerce", dayfirst=True)
            cancel = pd.to_datetime(canceling[i], errors="coerce", dayfirst=True)
            if cancel != 0 and date != 0 and cancel.month == date.month + 1 and 7 <= cancel.day <= 13:
                f[i] = 1
            else:
                f[i] = 0

        # print("train ", np.sum(f))
        # print("train total: ", full_data.shape[0])
        full_data["cancellation_datetime"] = f
        full_data = full_data[full_data['days_before_checking'] >= 0]

    enc = LabelEncoder()
    full_data["customer_nationality"] = enc.fit_transform(full_data["customer_nationality"])
    full_data["cancellation_policy_code"] = enc.fit_transform(full_data["cancellation_policy_code"])
    full_data["h_customer_id"] = enc.fit_transform(full_data["h_customer_id"])
    full_data["booking_datetime"] = enc.fit_transform(full_data["booking_datetime"])

    full_data["original_payment_type"] = enc.fit_transform(full_data["original_payment_type"])
    full_data["original_payment_method"] = enc.fit_transform(full_data["original_payment_method"])
    # book = np.zeros(full_data.shape[0])
    # booking = np.array(full_data["booking_datetime"])
    # for i in range(full_data.shape[0]):
    #     date = pd.to_datetime(booking[i], errors="coerce", dayfirst=True)
    #     book[i] = date.day
    # full_data["booking_datetime"] = book

    features = full_data[[
        # "is_first_booking",
        "cancellation_policy_code",
        "charge_option",
        # "no_of_adults",
        # "h_customer_id",
        # "hotel_star_rating",
        "guest_is_not_the_customer",
        "no_of_children",
        "no_of_room",
        "request_airport",
        # "hotel_area_code",
        # "hotel_brand_code",
        # "hotel_city_code",
        # "customer_nationality",
        # "hotel_id",
        # "original_payment_type",
        # "original_selling_amount",
        # "original_payment_method",
        # "is_user_logged_in",
        "request_earlycheckin",
        # "days_before_checking",
        # "booking_datetime"
    ]]

    if train:
        labels = full_data["cancellation_datetime"]
    else:
        labels = []
    return features, np.array(labels)


def evaluate_and_export(estimator: BaseEstimator, X: np.ndarray, filename: str):
    """
    Export to specified file the prediction results of given estimator on given testset.

    File saved is in csv format with a single column named 'predicted_values' and n_samples rows containing
    predicted values.

    Parameters
    ----------
    estimator: BaseEstimator or any object implementing predict() method as in BaseEstimator (for example sklearn)
        Fitted estimator to use for prediction

    X: ndarray of shape (n_samples, n_features)
        Test design matrix to predict its responses

    filename:
        path to store file at

    """
    x = estimator.predict(X)

    # print(np.sum(x))
    pd.DataFrame(estimator.predict(X), columns=["predicted_values"]).to_csv(filename, index=False)


if __name__ == '__main__':
    np.random.seed(0)

    # Load data
    df, cancellation_labels = load_data("../datasets/agoda_cancellation_train.csv")
    train_X, test_X, train_y, test_y = \
        train_test_split(df, cancellation_labels, test_size=0.15, random_state=42)

    # Fit model over data

    estimator = AgodaCancellationEstimator().fit(train_X, train_y)
    df_test, cancellation_labels = load_data("test_set_week_1.csv", False)

    # Store model predictions over test set
    evaluate_and_export(estimator, df_test, "318442241_208916221_207557935.csv")

    # print("train accuracy: ", 1 - estimator.loss(train_X, train_y))
    # print("test accuracy: ", 1 - estimator.loss(test_X, test_y))
